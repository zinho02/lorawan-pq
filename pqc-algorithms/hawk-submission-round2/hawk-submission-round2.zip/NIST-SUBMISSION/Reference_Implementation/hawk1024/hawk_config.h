#ifndef HAWK_CONFIG_H__
#define HAWK_CONFIG_H__
#define HAWK_PREFIX   hawk
#endif
